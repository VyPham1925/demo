!function(n){n.vungle=n.vungle||{}}(window);
